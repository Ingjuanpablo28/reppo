# declaremos el nombre de la base y aseguremos sea nueva
CREATE DATABASE IF NOT EXISTS marketess;
# una vez revisado que es nueva la bd la vamos a utilizar
USE marketess;

#vamos a crear la primer tabla independiente a partir del MER
CREATE TABLE IF NOT EXISTS usuarios(
Id_usuario INT UNIQUE PRIMARY KEY,
Nombreuno_usuario VARCHAR(50) NOT NULL,
Nombredos_usuario VARCHAR(50) NULL,
Apellidouno_usuario VARCHAR(50) NOT NULL,
Apellidodos_uusuario VARCHAR(50) NULL,
Correo VARCHAR(100) NOT NULL
);
#creamos la segunda tabla independiente 

CREATE TABLE IF NOT EXISTS productos(
Id_producto INT UNIQUE PRIMARY KEY,
Nombre_producto VARCHAR(100) NOT NULL,
Marca VARCHAR(100) NOT NULL,
Precio DECIMAL(10,2)
);
 
#vamos a definir los CONSTRAINT para las llaves foraneas
CREATE TABLE IF NOT EXISTS facturas(
Id_factura INT AUTO_INCREMENT UNIQUE PRIMARY KEY,
Id_usuario INT NOT NULL,
Id_producto INT NOT NULL,
Valortotal DECIMAL(10,2),

CONSTRAINT fk_factura_usuario FOREIGN KEY(Id_usuario) REFERENCES usuarios(Id_usuario),
CONSTRAINT fk_factura_producto FOREIGN KEY(Id_producto) REFERENCES productos(Id_producto)
);